import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { DogCard, DogModal } from './components/DogCard';
import { dogBreeds } from './data/dogBreeds';
import { NutritionPage } from './components/pages/NutritionPage';
import { TrainingPage } from './components/pages/TrainingPage';
import { HealthPage } from './components/pages/HealthPage';
import { OwnerPage } from './components/pages/OwnerPage';
import { Dog } from 'lucide-react';

function App() {
  const [selectedBreed, setSelectedBreed] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activePage, setActivePage] = useState('breeds');

  const handleCardClick = (breed) => {
    setSelectedBreed(breed);
    setIsModalOpen(true);
  };

  const renderContent = () => {
    switch (activePage) {
      case 'breeds':
        return (
          <div>
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold text-gray-900 mb-4">
                Esplora le Razze Canine
              </h2>
              <p className="text-xl text-gray-600">
                Clicca su una razza per scoprire le sue caratteristiche
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {dogBreeds.map((breed) => (
                <DogCard
                  key={breed.id}
                  breed={breed}
                  onClick={() => handleCardClick(breed)}
                />
              ))}
            </div>
          </div>
        );
      case 'nutrition':
        return <NutritionPage />;
      case 'training':
        return <TrainingPage />;
      case 'health':
        return <HealthPage />;
      case 'owner':
        return <OwnerPage />;
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Dog className="w-8 h-8 text-orange-500" />
              <h1 className="text-3xl font-bold text-gray-900">DogPedia</h1>
            </div>
            <p className="text-gray-600">La Guida Completa al Mondo dei Cani</p>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <Navigation activePage={activePage} onPageChange={setActivePage} />

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {renderContent()}
      </main>

      {/* Footer */}
      <footer className="bg-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>© 2024 DogPedia. Tutti i diritti riservati.</p>
          </div>
        </div>
      </footer>

      {/* Modal */}
      {selectedBreed && (
        <DogModal
          breed={selectedBreed}
          isOpen={isModalOpen}
          onClose={() => setIsModalOpen(false)}
        />
      )}
    </div>
  );
}

export default App;