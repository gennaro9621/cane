export const dogBreeds = [
  {
    id: 1,
    name: "Pastore Tedesco",
    image: "https://images.unsplash.com/photo-1589941013453-ec89f33b5e95?auto=format&fit=crop&w=800&q=80",
    origin: "Germania",
    temperament: "Sicuro, Coraggioso, Intelligente, Vigile, Fedele",
    lifeSpan: "9-13 anni",
    height: "55-65 cm",
    weight: "22-40 kg",
    description: "Il Pastore Tedesco è una razza di cane da lavoro di taglia medio-grande. Noto per la sua intelligenza, forza e capacità di addestramento, è uno dei cani più popolari al mondo.",
    characteristics: {
      adaptability: 5,
      friendliness: 4,
      grooming: 4,
      trainability: 5,
      exercise: 5
    }
  },
  {
    id: 2,
    name: "Golden Retriever",
    image: "https://images.unsplash.com/photo-1633722715463-d30f4f325e24?auto=format&fit=crop&w=800&q=80",
    origin: "Scozia",
    temperament: "Amichevole, Intelligente, Devoto, Fiducioso, Gentile",
    lifeSpan: "10-12 anni",
    height: "54-61 cm",
    weight: "25-34 kg",
    description: "Il Golden Retriever è una delle razze più popolari. Sono cani intelligenti e amichevoli, ottimi come cani da compagnia e spesso utilizzati come cani guida.",
    characteristics: {
      adaptability: 5,
      friendliness: 5,
      grooming: 3,
      trainability: 5,
      exercise: 4
    }
  },
  {
    id: 3,
    name: "Husky Siberiano",
    image: "https://images.unsplash.com/photo-1605568427561-40dd23c2acea?auto=format&fit=crop&w=800&q=80",
    origin: "Siberia",
    temperament: "Amichevole, Energico, Vigile, Estroverso",
    lifeSpan: "12-14 anni",
    height: "51-60 cm",
    weight: "16-27 kg",
    description: "L'Husky Siberiano è un cane da slitta artico noto per il suo aspetto attraente e la sua resistenza. Sono amichevoli ed energici.",
    characteristics: {
      adaptability: 3,
      friendliness: 5,
      grooming: 4,
      trainability: 3,
      exercise: 5
    }
  },
  {
    id: 4,
    name: "Bulldog Francese",
    image: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=800&q=80",
    origin: "Francia",
    temperament: "Giocoso, Adattabile, Intelligente, Affettuoso",
    lifeSpan: "10-12 anni",
    height: "28-33 cm",
    weight: "7-13 kg",
    description: "Il Bulldog Francese è una razza di piccola taglia nota per le sue orecchie a pipistrello. Sono ottimi cani da compagnia e si adattano bene alla vita cittadina.",
    characteristics: {
      adaptability: 5,
      friendliness: 4,
      grooming: 2,
      trainability: 4,
      exercise: 2
    }
  },
  {
    id: 5,
    name: "Labrador Retriever",
    image: "https://images.unsplash.com/photo-1591769225440-811ad7d6eab3?auto=format&fit=crop&w=800&q=80",
    origin: "Canada",
    temperament: "Amichevole, Attivo, Estroverso, Intelligente",
    lifeSpan: "10-12 anni",
    height: "54-62 cm",
    weight: "25-36 kg",
    description: "Il Labrador Retriever è una delle razze più popolari al mondo. Noti per la loro natura amichevole e intelligenza, eccellono come cani da compagnia e da lavoro.",
    characteristics: {
      adaptability: 5,
      friendliness: 5,
      grooming: 3,
      trainability: 5,
      exercise: 5
    }
  },
  {
    id: 6,
    name: "Beagle",
    image: "https://images.unsplash.com/photo-1505628346881-b72b27e84530?auto=format&fit=crop&w=800&q=80",
    origin: "Regno Unito",
    temperament: "Allegro, Curioso, Amichevole, Determinato",
    lifeSpan: "12-15 anni",
    height: "33-40 cm",
    weight: "9-11 kg",
    description: "Il Beagle è un cane da caccia di piccola taglia, noto per il suo eccellente olfatto e la sua natura amichevole. Sono ottimi cani da famiglia.",
    characteristics: {
      adaptability: 4,
      friendliness: 5,
      grooming: 3,
      trainability: 3,
      exercise: 4
    }
  },
  {
    id: 7,
    name: "Rottweiler",
    image: "https://images.unsplash.com/photo-1567752881298-894bb81f9379?auto=format&fit=crop&w=800&q=80",
    origin: "Germania",
    temperament: "Devoto, Protettivo, Calmo, Sicuro",
    lifeSpan: "8-10 anni",
    height: "56-69 cm",
    weight: "35-60 kg",
    description: "Il Rottweiler è un cane robusto e muscoloso, tradizionalmente utilizzato come cane da guardia e da bestiame. Sono molto leali verso la famiglia.",
    characteristics: {
      adaptability: 4,
      friendliness: 3,
      grooming: 2,
      trainability: 4,
      exercise: 4
    }
  },
  {
    id: 8,
    name: "Boxer",
    image: "https://images.unsplash.com/photo-1543071220-6ee5bf71a54e?auto=format&fit=crop&w=800&q=80",
    origin: "Germania",
    temperament: "Giocoso, Paziente, Protettivo, Energico",
    lifeSpan: "10-12 anni",
    height: "53-63 cm",
    weight: "25-32 kg",
    description: "Il Boxer è un cane di taglia media, noto per la sua natura giocosa e protettiva. Sono eccellenti con i bambini e fanno ottimi cani da guardia.",
    characteristics: {
      adaptability: 4,
      friendliness: 4,
      grooming: 2,
      trainability: 4,
      exercise: 5
    }
  },
  {
    id: 9,
    name: "Dalmata",
    image: "https://images.unsplash.com/photo-1583512603806-077998240c7a?auto=format&fit=crop&w=800&q=80",
    origin: "Croazia",
    temperament: "Energico, Giocoso, Intelligente, Leale",
    lifeSpan: "12-14 anni",
    height: "48-58 cm",
    weight: "23-25 kg",
    description: "Il Dalmata è famoso per il suo mantello unico a macchie. Sono cani energici e resistenti, tradizionalmente utilizzati come cani da carrozza.",
    characteristics: {
      adaptability: 4,
      friendliness: 4,
      grooming: 2,
      trainability: 4,
      exercise: 5
    }
  },
  {
    id: 10,
    name: "Chihuahua",
    image: "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&w=800&q=80",
    origin: "Messico",
    temperament: "Vivace, Coraggioso, Devoto, Vigile",
    lifeSpan: "12-20 anni",
    height: "15-23 cm",
    weight: "1.5-3 kg",
    description: "Il Chihuahua è la razza più piccola al mondo. Sono cani vivaci e coraggiosi, molto devoti ai loro proprietari.",
    characteristics: {
      adaptability: 5,
      friendliness: 3,
      grooming: 2,
      trainability: 3,
      exercise: 2
    }
  }
  // ... continua con altre razze fino a 50-60
];