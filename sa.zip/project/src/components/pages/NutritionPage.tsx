import React from 'react';

export const NutritionPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold mb-6">Guida all'Alimentazione Canina</h2>
      
      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Principi Base dell'Alimentazione</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="space-y-4">
            <li>
              <strong className="text-orange-600">Proteine:</strong>
              <p>Essenziali per muscoli e tessuti. Fonti principali: carne, pesce, uova.</p>
            </li>
            <li>
              <strong className="text-orange-600">Carboidrati:</strong>
              <p>Fonte di energia. Presenti in riso, patate, cereali integrali.</p>
            </li>
            <li>
              <strong className="text-orange-600">Grassi:</strong>
              <p>Necessari per energia e vitamine liposolubili. Fonti: oli, pesci grassi.</p>
            </li>
            <li>
              <strong className="text-orange-600">Vitamine e Minerali:</strong>
              <p>Fondamentali per il sistema immunitario e la salute generale.</p>
            </li>
          </ul>
        </div>
      </section>

      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Frequenza dei Pasti</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="space-y-3">
            <li>Cuccioli (2-3 mesi): 4 pasti al giorno</li>
            <li>Cuccioli (4-6 mesi): 3 pasti al giorno</li>
            <li>Cani adulti: 2 pasti al giorno</li>
            <li>Cani anziani: 2-3 pasti più leggeri</li>
          </ul>
        </div>
      </section>

      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Alimenti da Evitare</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ul className="space-y-2">
              <li>❌ Cioccolato</li>
              <li>❌ Cipolla e aglio</li>
              <li>❌ Uva e uvetta</li>
              <li>❌ Avocado</li>
            </ul>
            <ul className="space-y-2">
              <li>❌ Noci di macadamia</li>
              <li>❌ Xilitolo (dolcificante)</li>
              <li>❌ Ossa cotte</li>
              <li>❌ Caffè e teina</li>
            </ul>
          </div>
        </div>
      </section>

      <section>
        <h3 className="text-2xl font-semibold mb-4">Consigli per l'Alimentazione</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="space-y-4">
            <li>✅ Mantenere sempre acqua fresca a disposizione</li>
            <li>✅ Rispettare gli orari dei pasti</li>
            <li>✅ Evitare esercizio fisico intenso subito dopo i pasti</li>
            <li>✅ Adattare la dieta all'età e al livello di attività</li>
            <li>✅ Consultare il veterinario per diete specifiche</li>
          </ul>
        </div>
      </section>
    </div>
  );
};