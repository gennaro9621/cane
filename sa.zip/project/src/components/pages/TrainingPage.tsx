import React from 'react';

export const TrainingPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold mb-6">Guida all'Addestramento Base</h2>

      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Comandi Base</h3>
        <div className="grid gap-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h4 className="text-xl font-medium text-orange-600 mb-3">"Seduto"</h4>
            <ol className="list-decimal list-inside space-y-2">
              <li>Mostra al cane un premio</li>
              <li>Tieni il premio sopra la sua testa</li>
              <li>Muovi lentamente il premio indietro</li>
              <li>Quando si siede, premialo</li>
            </ol>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h4 className="text-xl font-medium text-orange-600 mb-3">"Terra"</h4>
            <ol className="list-decimal list-inside space-y-2">
              <li>Parti dalla posizione "seduto"</li>
              <li>Mostra il premio e abbassalo al suolo</li>
              <li>Muovi il premio in avanti</li>
              <li>Premia quando si sdraia</li>
            </ol>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h4 className="text-xl font-medium text-orange-600 mb-3">"Vieni"</h4>
            <ol className="list-decimal list-inside space-y-2">
              <li>Chiama il cane con voce allegra</li>
              <li>Mostra il premio</li>
              <li>Allontanati leggermente</li>
              <li>Premia quando arriva da te</li>
            </ol>
          </div>
        </div>
      </section>

      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Principi Fondamentali</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="space-y-4">
            <li>
              <strong className="text-orange-600">Coerenza:</strong>
              <p>Usa sempre gli stessi comandi e regole</p>
            </li>
            <li>
              <strong className="text-orange-600">Tempismo:</strong>
              <p>Premia immediatamente il comportamento corretto</p>
            </li>
            <li>
              <strong className="text-orange-600">Pazienza:</strong>
              <p>Ogni cane ha i suoi tempi di apprendimento</p>
            </li>
            <li>
              <strong className="text-orange-600">Rinforzo positivo:</strong>
              <p>Premia i comportamenti desiderati</p>
            </li>
          </ul>
        </div>
      </section>

      <section>
        <h3 className="text-2xl font-semibold mb-4">Errori da Evitare</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="space-y-3">
            <li>❌ Punizioni fisiche</li>
            <li>❌ Sessioni di addestramento troppo lunghe</li>
            <li>❌ Inconsistenza nei comandi</li>
            <li>❌ Addestrare quando il cane è stanco</li>
            <li>❌ Forzare situazioni stressanti</li>
          </ul>
        </div>
      </section>
    </div>
  );
};