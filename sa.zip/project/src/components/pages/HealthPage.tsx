import React from 'react';

export const HealthPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold mb-6">Salute e Malattie Comuni</h2>

      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Prevenzione</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="space-y-4">
            <li>
              <strong className="text-orange-600">Vaccinazioni:</strong>
              <p>Seguire il calendario vaccinale consigliato dal veterinario</p>
            </li>
            <li>
              <strong className="text-orange-600">Antiparassitari:</strong>
              <p>Trattamenti regolari contro pulci, zecche e vermi</p>
            </li>
            <li>
              <strong className="text-orange-600">Check-up:</strong>
              <p>Visite veterinarie regolari, almeno una volta l'anno</p>
            </li>
            <li>
              <strong className="text-orange-600">Igiene dentale:</strong>
              <p>Pulizia regolare dei denti e controllo del tartaro</p>
            </li>
          </ul>
        </div>
      </section>

      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Malattie Comuni</h3>
        <div className="grid gap-4">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h4 className="text-xl font-medium text-orange-600 mb-3">Problemi Gastrointestinali</h4>
            <ul className="space-y-2">
              <li>• Vomito</li>
              <li>• Diarrea</li>
              <li>• Costipazione</li>
              <li>• Inappetenza</li>
            </ul>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h4 className="text-xl font-medium text-orange-600 mb-3">Problemi Dermatologici</h4>
            <ul className="space-y-2">
              <li>• Dermatiti</li>
              <li>• Allergie</li>
              <li>• Infezioni fungine</li>
              <li>• Acariasi</li>
            </ul>
          </div>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h4 className="text-xl font-medium text-orange-600 mb-3">Problemi Ortopedici</h4>
            <ul className="space-y-2">
              <li>• Displasia dell'anca</li>
              <li>• Artrite</li>
              <li>• Lussazione della rotula</li>
              <li>• Problemi alla colonna vertebrale</li>
            </ul>
          </div>
        </div>
      </section>

      <section>
        <h3 className="text-2xl font-semibold mb-4">Segnali d'Allarme</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <ul className="space-y-2">
              <li>🚨 Cambiamenti nell'appetito</li>
              <li>🚨 Letargia o debolezza</li>
              <li>🚨 Difficoltà respiratorie</li>
              <li>🚨 Vomito frequente</li>
            </ul>
            <ul className="space-y-2">
              <li>🚨 Diarrea persistente</li>
              <li>🚨 Zoppia</li>
              <li>🚨 Tosse persistente</li>
              <li>🚨 Cambiamenti comportamentali</li>
            </ul>
          </div>
        </div>
      </section>
    </div>
  );
};