import React from 'react';

export const OwnerPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <h2 className="text-3xl font-bold mb-6">Guida per il Buon Padrone</h2>

      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Responsabilità Base</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="space-y-4">
            <li>
              <strong className="text-orange-600">Cure Mediche:</strong>
              <p>Vaccinazioni regolari, visite veterinarie, prevenzione parassiti</p>
            </li>
            <li>
              <strong className="text-orange-600">Alimentazione:</strong>
              <p>Cibo di qualità, acqua fresca, orari regolari</p>
            </li>
            <li>
              <strong className="text-orange-600">Esercizio:</strong>
              <p>Passeggiate quotidiane, gioco e stimolazione mentale</p>
            </li>
            <li>
              <strong className="text-orange-600">Igiene:</strong>
              <p>Spazzolatura regolare, bagni quando necessario, pulizia denti</p>
            </li>
          </ul>
        </div>
      </section>

      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Aspetti Legali</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="space-y-3">
            <li>📋 Microchip obbligatorio</li>
            <li>📋 Registrazione all'anagrafe canina</li>
            <li>📋 Guinzaglio in luoghi pubblici</li>
            <li>📋 Raccolta deiezioni</li>
            <li>📋 Assicurazione (consigliata)</li>
          </ul>
        </div>
      </section>

      <section className="mb-8">
        <h3 className="text-2xl font-semibold mb-4">Socializzazione</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <ul className="space-y-4">
            <li>
              <strong className="text-orange-600">Con persone:</strong>
              <p>Esporre il cane a diverse persone in modo positivo</p>
            </li>
            <li>
              <strong className="text-orange-600">Con altri cani:</strong>
              <p>Incontri controllati con cani vaccinati e socievoli</p>
            </li>
            <li>
              <strong className="text-orange-600">Con l'ambiente:</strong>
              <p>Esposizione graduale a diversi ambienti e situazioni</p>
            </li>
          </ul>
        </div>
      </section>

      <section>
        <h3 className="text-2xl font-semibold mb-4">Consigli Quotidiani</h3>
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="grid gap-6">
            <div>
              <h4 className="text-lg font-medium text-orange-600 mb-2">Routine Giornaliera</h4>
              <ul className="space-y-2">
                <li>• Orari regolari per pasti e passeggiate</li>
                <li>• Momenti dedicati al gioco e all'addestramento</li>
                <li>• Tempo per il riposo e il relax</li>
                <li>• Controllo quotidiano della salute</li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-lg font-medium text-orange-600 mb-2">Comunicazione</h4>
              <ul className="space-y-2">
                <li>• Osservare il linguaggio del corpo</li>
                <li>• Mantenere un tono di voce appropriato</li>
                <li>• Essere coerenti nei comandi</li>
                <li>• Premiare i comportamenti positivi</li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-medium text-orange-600 mb-2">Sicurezza</h4>
              <ul className="space-y-2">
                <li>• Casa a prova di cane</li>
                <li>• Identificazione sempre visibile</li>
                <li>• Piano di emergenza veterinaria</li>
                <li>• Trasporto sicuro in auto</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};