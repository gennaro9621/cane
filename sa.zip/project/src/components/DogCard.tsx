import React from 'react';
import { X } from 'lucide-react';

interface DogBreed {
  id: number;
  name: string;
  image: string;
  origin: string;
  temperament: string;
  lifeSpan: string;
  height: string;
  weight: string;
  description: string;
  characteristics: {
    adaptability: number;
    friendliness: number;
    grooming: number;
    trainability: number;
    exercise: number;
  };
}

interface DogCardProps {
  breed: DogBreed;
  onClick: () => void;
}

interface ModalProps {
  breed: DogBreed;
  onClose: () => void;
  isOpen: boolean;
}

const RatingStars: React.FC<{ rating: number }> = ({ rating }) => {
  return (
    <div className="flex gap-1">
      {[...Array(5)].map((_, index) => (
        <div
          key={index}
          className={`w-4 h-4 rounded-full ${
            index < rating ? 'bg-yellow-400' : 'bg-gray-200'
          }`}
        />
      ))}
    </div>
  );
};

export const DogCard: React.FC<DogCardProps> = ({ breed, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="bg-white rounded-xl shadow-lg overflow-hidden cursor-pointer transform transition-transform hover:scale-105"
    >
      <div className="h-48 overflow-hidden">
        <img
          src={breed.image}
          alt={breed.name}
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-4">
        <h3 className="text-xl font-semibold text-gray-800">{breed.name}</h3>
        <p className="text-gray-600 mt-1">{breed.origin}</p>
      </div>
    </div>
  );
};

export const DogModal: React.FC<ModalProps> = ({ breed, onClose, isOpen }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="relative">
          <button
            onClick={onClose}
            className="absolute right-4 top-4 p-2 rounded-full bg-white/90 hover:bg-gray-100 transition-colors"
          >
            <X className="w-6 h-6 text-gray-600" />
          </button>
          <img
            src={breed.image}
            alt={breed.name}
            className="w-full h-64 object-cover rounded-t-2xl"
          />
        </div>
        
        <div className="p-6">
          <h2 className="text-3xl font-bold text-gray-800 mb-2">{breed.name}</h2>
          <p className="text-gray-600 mb-6">{breed.description}</p>
          
          <div className="grid grid-cols-2 gap-6 mb-6">
            <div>
              <h3 className="font-semibold text-gray-700 mb-2">Basic Information</h3>
              <ul className="space-y-2">
                <li><span className="font-medium">Origin:</span> {breed.origin}</li>
                <li><span className="font-medium">Life Span:</span> {breed.lifeSpan}</li>
                <li><span className="font-medium">Height:</span> {breed.height}</li>
                <li><span className="font-medium">Weight:</span> {breed.weight}</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-semibold text-gray-700 mb-2">Characteristics</h3>
              <div className="space-y-3">
                <div>
                  <span className="text-sm text-gray-600">Adaptability</span>
                  <RatingStars rating={breed.characteristics.adaptability} />
                </div>
                <div>
                  <span className="text-sm text-gray-600">Friendliness</span>
                  <RatingStars rating={breed.characteristics.friendliness} />
                </div>
                <div>
                  <span className="text-sm text-gray-600">Grooming Needs</span>
                  <RatingStars rating={breed.characteristics.grooming} />
                </div>
                <div>
                  <span className="text-sm text-gray-600">Trainability</span>
                  <RatingStars rating={breed.characteristics.trainability} />
                </div>
                <div>
                  <span className="text-sm text-gray-600">Exercise Needs</span>
                  <RatingStars rating={breed.characteristics.exercise} />
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-4">
            <h3 className="font-semibold text-gray-700 mb-2">Temperament</h3>
            <p className="text-gray-600">{breed.temperament}</p>
          </div>
        </div>
      </div>
    </div>
  );
};