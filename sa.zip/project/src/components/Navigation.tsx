import React from 'react';
import { Dog, Utensils, School, Heart, User } from 'lucide-react';

interface NavItemProps {
  icon: React.ReactNode;
  text: string;
  isActive: boolean;
  onClick: () => void;
}

const NavItem: React.FC<NavItemProps> = ({ icon, text, isActive, onClick }) => (
  <button
    onClick={onClick}
    className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
      isActive 
        ? 'bg-orange-100 text-orange-600' 
        : 'hover:bg-orange-50 text-gray-600 hover:text-orange-500'
    }`}
  >
    {icon}
    <span className="font-medium">{text}</span>
  </button>
);

interface NavigationProps {
  activePage: string;
  onPageChange: (page: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ activePage, onPageChange }) => {
  return (
    <nav className="flex flex-wrap justify-center gap-4 p-4 bg-white shadow-sm">
      <NavItem
        icon={<Dog className="w-5 h-5" />}
        text="Razze"
        isActive={activePage === 'breeds'}
        onClick={() => onPageChange('breeds')}
      />
      <NavItem
        icon={<Utensils className="w-5 h-5" />}
        text="Alimentazione"
        isActive={activePage === 'nutrition'}
        onClick={() => onPageChange('nutrition')}
      />
      <NavItem
        icon={<School className="w-5 h-5" />}
        text="Addestramento"
        isActive={activePage === 'training'}
        onClick={() => onPageChange('training')}
      />
      <NavItem
        icon={<Heart className="w-5 h-5" />}
        text="Salute"
        isActive={activePage === 'health'}
        onClick={() => onPageChange('health')}
      />
      <NavItem
        icon={<User className="w-5 h-5" />}
        text="Buon Padrone"
        isActive={activePage === 'owner'}
        onClick={() => onPageChange('owner')}
      />
    </nav>
  );
};